---
draft: false
name: "Marcell Ziemann"
title: "Principal Strategist"
avatar: {
    src: "https://images.unsplash.com/photo-1633332755192-727a05c4013d?&fit=crop&w=280",
    alt: "Marcell Ziemann"
}
publishDate: "2022-11-08 15:39"
---
