---
draft: false
name: "Janette Lynch"
title: "Senior Director"
avatar: {
    src: "https://images.unsplash.com/photo-1580489944761-15a19d654956?&fit=crop&w=280",
    alt: "Janette Lynch"
}
publishDate: "2022-11-07 15:39"
---
